import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Heart, 
  Search, 
  Home, 
  Library, 
  Volume2, 
  VolumeX,
  Music,
  TrendingUp,
  Clock,
  MoreHorizontal,
  Plus,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Song, MOCK_SONGS } from './types';
import { Equalizer } from './components/Equalizer';
import { cn } from './lib/utils';

export default function App() {
  const [songs, setSongs] = useState<Song[]>(MOCK_SONGS);
  const [currentSong, setCurrentSong] = useState<Song | null>(MOCK_SONGS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [likedSongs, setLikedSongs] = useState<string[]>([]);
  const [volume, setVolume] = useState(0.7);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [activeTab, setActiveTab] = useState<'home' | 'search' | 'liked'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [selectedArtist, setSelectedArtist] = useState<string>('All');
  const [selectedAlbum, setSelectedAlbum] = useState<string>('All');

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const genres = ['All', ...Array.from(new Set(songs.map(s => s.genre)))];
  const artists = ['All', ...Array.from(new Set(songs.map(s => s.artist)))];
  const albums = ['All', ...Array.from(new Set(songs.map(s => s.album)))];

  // Simulate "automatically update" by adding a new song every few minutes
  const searchSongs = async (query: string) => {
    if (!query) return;
    setIsSearching(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `I am building a music app. The user searched for "${query}". 
        Please provide 3-5 real songs that match this search. 
        Return the result as a JSON array of objects with fields: 
        title, artist, album, genre, duration (seconds). 
        Do not include any other text.`,
        config: {
          responseMimeType: "application/json"
        }
      });

      const results = JSON.parse(response.text);
      const newSongs: Song[] = results.map((s: any, i: number) => ({
        id: `search-${Date.now()}-${i}`,
        title: s.title,
        artist: s.artist,
        album: s.album,
        coverUrl: `https://picsum.photos/seed/${s.title.replace(/\s/g, '')}/400/400`,
        audioUrl: `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(i % 15) + 1}.mp3`,
        duration: s.duration || 200,
        genre: s.genre || 'Various'
      }));

      setSongs(prev => {
        const existingIds = new Set(prev.map(s => s.id));
        const uniqueNew = newSongs.filter(s => !existingIds.has(s.id));
        return [...uniqueNew, ...prev];
      });
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery.length > 2) {
        searchSongs(searchQuery);
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Load liked songs from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('vibe_liked_songs');
    if (saved) setLikedSongs(JSON.parse(saved));
  }, []);

  // Save liked songs to localStorage
  useEffect(() => {
    localStorage.setItem('vibe_liked_songs', JSON.stringify(likedSongs));
  }, [likedSongs]);

  // Handle audio playback
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(e => console.error("Playback failed:", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentSong]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const togglePlay = () => setIsPlaying(!isPlaying);

  const toggleLike = (id: string) => {
    setLikedSongs(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const handleSongSelect = (song: Song) => {
    if (currentSong?.id === song.id) {
      togglePlay();
    } else {
      setCurrentSong(song);
      setIsPlaying(true);
    }
  };

  const handleNext = () => {
    const currentIndex = songs.findIndex(s => s.id === currentSong?.id);
    const nextIndex = (currentIndex + 1) % songs.length;
    setCurrentSong(songs[nextIndex]);
    setIsPlaying(true);
  };

  const handlePrev = () => {
    const currentIndex = songs.findIndex(s => s.id === currentSong?.id);
    const prevIndex = (currentIndex - 1 + songs.length) % songs.length;
    setCurrentSong(songs[prevIndex]);
    setIsPlaying(true);
  };

  const formatTime = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredSongs = songs.filter(s => {
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         s.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         s.album.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'All' || s.genre === selectedGenre;
    const matchesArtist = selectedArtist === 'All' || s.artist === selectedArtist;
    const matchesAlbum = selectedAlbum === 'All' || s.album === selectedAlbum;
    
    return matchesSearch && matchesGenre && matchesArtist && matchesAlbum;
  });

  const displaySongs = activeTab === 'liked' 
    ? songs.filter(s => likedSongs.includes(s.id))
    : filteredSongs;

  return (
    <div className="flex h-screen bg-bg text-white overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-black border-r border-white/10 flex flex-col p-6 space-y-8">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
            <Music className="text-black w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tighter">VIBESTREAM</span>
        </div>

        <nav className="space-y-4">
          <button 
            onClick={() => setActiveTab('home')}
            className={cn(
              "flex items-center space-x-3 w-full p-2 rounded-lg transition-colors",
              activeTab === 'home' ? "bg-white/10 text-white" : "text-white/50 hover:text-white"
            )}
          >
            <Home size={20} />
            <span className="font-medium">Home</span>
          </button>
          <button 
            onClick={() => setActiveTab('search')}
            className={cn(
              "flex items-center space-x-3 w-full p-2 rounded-lg transition-colors",
              activeTab === 'search' ? "bg-white/10 text-white" : "text-white/50 hover:text-white"
            )}
          >
            <Search size={20} />
            <span className="font-medium">Search</span>
          </button>
          <button 
            onClick={() => setActiveTab('liked')}
            className={cn(
              "flex items-center space-x-3 w-full p-2 rounded-lg transition-colors",
              activeTab === 'liked' ? "bg-white/10 text-white" : "text-white/50 hover:text-white"
            )}
          >
            <Heart size={20} fill={activeTab === 'liked' ? "currentColor" : "none"} />
            <span className="font-medium">Liked Songs</span>
          </button>
        </nav>

        <div className="pt-8 border-t border-white/10">
          <h3 className="text-xs font-bold text-white/30 uppercase tracking-widest mb-4">Your Playlists</h3>
          <div className="space-y-3">
            <button className="flex items-center space-x-2 text-white/50 hover:text-white transition-colors group">
              <div className="w-6 h-6 bg-white/10 rounded flex items-center justify-center group-hover:bg-white/20">
                <Plus size={14} />
              </div>
              <span className="text-sm font-medium">Create Playlist</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto no-scrollbar relative">
        {/* Header Background Gradient */}
        <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-accent/20 to-transparent pointer-events-none" />

        <div className="p-8 relative z-10">
          {activeTab === 'search' && (
            <div className="mb-8 space-y-4">
              <div className="relative max-w-xl">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={20} />
                <input 
                  type="text" 
                  placeholder="What do you want to listen to?"
                  className="w-full bg-white/5 border border-white/10 rounded-full py-3 pl-12 pr-12 focus:outline-none focus:border-accent/50 transition-colors"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                {isSearching && (
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-accent animate-spin">
                    <Loader2 size={20} />
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white/30 uppercase tracking-widest">Genre:</span>
                  <select 
                    value={selectedGenre}
                    onChange={(e) => setSelectedGenre(e.target.value)}
                    className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm focus:outline-none focus:border-accent/50"
                  >
                    {genres.map(g => <option key={g} value={g} className="bg-bg">{g}</option>)}
                  </select>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white/30 uppercase tracking-widest">Artist:</span>
                  <select 
                    value={selectedArtist}
                    onChange={(e) => setSelectedArtist(e.target.value)}
                    className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm focus:outline-none focus:border-accent/50"
                  >
                    {artists.map(a => <option key={a} value={a} className="bg-bg">{a}</option>)}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white/30 uppercase tracking-widest">Album:</span>
                  <select 
                    value={selectedAlbum}
                    onChange={(e) => setSelectedAlbum(e.target.value)}
                    className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm focus:outline-none focus:border-accent/50"
                  >
                    {albums.map(a => <option key={a} value={a} className="bg-bg">{a}</option>)}
                  </select>
                </div>
                
                {(selectedGenre !== 'All' || selectedArtist !== 'All' || selectedAlbum !== 'All') && (
                  <button 
                    onClick={() => { setSelectedGenre('All'); setSelectedArtist('All'); setSelectedAlbum('All'); }}
                    className="text-xs font-bold text-accent uppercase tracking-widest hover:underline"
                  >
                    Clear Filters
                  </button>
                )}
              </div>
            </div>
          )}

          <header className="mb-12">
            <h1 className="text-4xl font-bold mb-2">
              {activeTab === 'home' ? 'Good Evening' : activeTab === 'search' ? 'Search' : 'Liked Songs'}
            </h1>
            <p className="text-white/50">
              {activeTab === 'home' ? 'Discover new music tailored for you.' : ''}
            </p>
          </header>

          {/* New Releases Section */}
          {activeTab === 'home' && !searchQuery && (
            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <TrendingUp className="text-accent" /> New Releases
                </h2>
                <button className="text-xs font-bold text-white/50 uppercase tracking-widest hover:text-white">See All</button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {songs.filter(s => s.isNew).map(song => (
                  <SongCard 
                    key={song.id} 
                    song={song} 
                    isCurrent={currentSong?.id === song.id}
                    isPlaying={isPlaying && currentSong?.id === song.id}
                    onSelect={() => handleSongSelect(song)}
                    onLike={() => toggleLike(song.id)}
                    isLiked={likedSongs.includes(song.id)}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Main Grid */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">
                {activeTab === 'liked' ? 'Your Favorites' : 'Jump Back In'}
              </h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {displaySongs.map(song => (
                <SongCard 
                  key={song.id} 
                  song={song} 
                  isCurrent={currentSong?.id === song.id}
                  isPlaying={isPlaying && currentSong?.id === song.id}
                  onSelect={() => handleSongSelect(song)}
                  onLike={() => toggleLike(song.id)}
                  isLiked={likedSongs.includes(song.id)}
                />
              ))}
            </div>
          </section>
        </div>
      </main>

      {/* Player Bar */}
      <footer className="fixed bottom-0 left-0 right-0 h-24 bg-black/90 backdrop-blur-xl border-t border-white/10 px-6 flex items-center justify-between z-50">
        {/* Song Info */}
        <div className="flex items-center space-x-4 w-1/3">
          {currentSong ? (
            <>
              <div className="w-14 h-14 rounded-lg overflow-hidden shadow-2xl relative group">
                <img 
                  src={currentSong.coverUrl} 
                  alt={currentSong.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Equalizer audioElement={audioRef.current} isPlaying={isPlaying} />
                </div>
              </div>
              <div>
                <h4 className="font-bold text-sm truncate max-w-[200px]">{currentSong.title}</h4>
                <p className="text-xs text-white/50 truncate max-w-[200px]">{currentSong.artist}</p>
              </div>
              <button 
                onClick={() => toggleLike(currentSong.id)}
                className={cn(
                  "transition-colors",
                  likedSongs.includes(currentSong.id) ? "text-accent" : "text-white/30 hover:text-white"
                )}
              >
                <Heart size={18} fill={likedSongs.includes(currentSong.id) ? "currentColor" : "none"} />
              </button>
            </>
          ) : (
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 bg-white/5 rounded-lg" />
              <div className="space-y-2">
                <div className="w-24 h-3 bg-white/5 rounded" />
                <div className="w-16 h-2 bg-white/5 rounded" />
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-col items-center w-1/3 space-y-2">
          <div className="flex items-center space-x-6">
            <button className="text-white/50 hover:text-white transition-colors"><SkipBack size={20} onClick={handlePrev} /></button>
            <button 
              onClick={togglePlay}
              className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-black hover:scale-105 transition-transform"
            >
              {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-1" />}
            </button>
            <button className="text-white/50 hover:text-white transition-colors"><SkipForward size={20} onClick={handleNext} /></button>
          </div>
          
          <div className="flex items-center space-x-2 w-full max-w-md">
            <span className="text-[10px] text-white/30 font-mono w-8 text-right">{formatTime(currentTime)}</span>
            <div className="flex-1 h-1 bg-white/10 rounded-full relative group cursor-pointer">
              <div 
                className="absolute top-0 left-0 h-full bg-accent rounded-full" 
                style={{ width: `${(currentTime / (currentSong?.duration || 1)) * 100}%` }}
              />
              <div 
                className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                style={{ left: `${(currentTime / (currentSong?.duration || 1)) * 100}%` }}
              />
            </div>
            <span className="text-[10px] text-white/30 font-mono w-8">{formatTime(currentSong?.duration || 0)}</span>
          </div>
        </div>

        {/* Volume & Equalizer */}
        <div className="flex items-center justify-end space-x-4 w-1/3">
          <div className="hidden lg:block mr-4">
            <Equalizer audioElement={audioRef.current} isPlaying={isPlaying} />
          </div>
          <button onClick={() => setIsMuted(!isMuted)} className="text-white/50 hover:text-white transition-colors">
            {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
          <div className="w-24 h-1 bg-white/10 rounded-full relative group cursor-pointer">
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.01" 
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                setVolume(parseFloat(e.target.value));
                setIsMuted(false);
              }}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
            <div 
              className="absolute top-0 left-0 h-full bg-white/50 group-hover:bg-accent rounded-full transition-colors" 
              style={{ width: `${(isMuted ? 0 : volume) * 100}%` }}
            />
          </div>
        </div>
      </footer>

      {/* Hidden Audio Element */}
      <audio 
        ref={audioRef}
        src={currentSong?.audioUrl}
        onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
        onEnded={handleNext}
      />
    </div>
  );
}

interface SongCardProps {
  song: Song;
  isCurrent: boolean;
  isPlaying: boolean;
  onSelect: () => void;
  onLike: () => void;
  isLiked: boolean;
}

const SongCard: React.FC<SongCardProps> = ({ song, isCurrent, isPlaying, onSelect, onLike, isLiked }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "group p-4 rounded-xl transition-all duration-300 cursor-pointer relative",
        isCurrent ? "bg-white/10" : "bg-white/5 hover:bg-white/10"
      )}
      onClick={onSelect}
    >
      <div className="relative aspect-square rounded-lg overflow-hidden mb-4 shadow-xl">
        <img 
          src={song.coverUrl} 
          alt={song.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className={cn(
          "absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity duration-300",
          isPlaying ? "opacity-100" : "opacity-0 group-hover:opacity-100"
        )}>
          <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center text-black shadow-2xl transform scale-90 group-hover:scale-100 transition-transform">
            {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
          </div>
        </div>
        {song.isNew && (
          <div className="absolute top-2 left-2 bg-accent text-black text-[10px] font-bold px-2 py-1 rounded uppercase tracking-tighter">
            New
          </div>
        )}
      </div>
      
      <div className="flex justify-between items-start">
        <div className="flex-1 min-w-0">
          <h3 className={cn(
            "font-bold text-sm truncate mb-1",
            isCurrent ? "text-accent" : "text-white"
          )}>
            {song.title}
          </h3>
          <p className="text-xs text-white/50 truncate">{song.artist}</p>
        </div>
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onLike();
          }}
          className={cn(
            "ml-2 transition-all transform hover:scale-125",
            isLiked ? "text-accent" : "text-white/0 group-hover:text-white/30 hover:text-white"
          )}
        >
          <Heart size={16} fill={isLiked ? "currentColor" : "none"} />
        </button>
      </div>
    </motion.div>
  );
}
